#include <iostream>
#include <fstream>
#include <string>
#include <cstring>

using namespace std;

int main()
{
	string input1, input2, input3, input4;

	ifstream infile;
	infile.open("InFile Test Program\\csvtest.txt", ios::in); // I forgot the ios::in which seems to be why getline() wasn't working.

	while (infile.good())
	{
		// infile >> input1;
		getline(infile, input1, ',');
		for (int x = 0; x < input1.length(); x++)
			if (input1[x] == ',')
				input1[x] = '\0';
		cout << input1 << "\n";

		//infile >> input2;
		getline(infile, input2, ',');
		for (int x = 0; x < input2.length(); x++)
			if (input2[x] == ',')
				input2[x] = '\0';
		cout << input2 << "\n";

		//infile >> input3;
		getline(infile, input3, ',');
		for (int x = 0; x < input3.length(); x++)
			if (input3[x] == ',')
				input3[x] = '\0';
		cout << input3 << "\n";

		//infile >> input4;
		getline(infile, input4, ',');
		for (int x = 0; x < input4.length(); x++)
			if (input4[x] == ',')
				input4[x] = '\0';
		cout << input4 << "\n";
	}

	infile.close();

	return 0;
}